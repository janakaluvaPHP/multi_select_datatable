<?php 

//database_connection.php

// $connect = new PDO("mysql:host=localhost;dbname=testing", "root", "");
$connect = new PDO("pgsql:host=localhost;port=5432;dbname=postgres;user=postgres;password=root");

?>